﻿Imports System.Data.SqlClient
Public Class FrmEditDonorRegistration
    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Dim ds As DataSet
    Dim da As SqlDataAdapter
    Dim str As String
    Dim nationality As String
    Dim membership As String
    Dim SpecialEnvite As String

    Private Sub FrmDonorRegistration_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New SqlConnection("Data Source=CC-PC;Initial Catalog=DonationManagement;Persist Security Info=True;User ID=sa;Password=rudh012")
        con.Open()
    End Sub

    


    Private Sub btnContinue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnContinue.Click
       
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class